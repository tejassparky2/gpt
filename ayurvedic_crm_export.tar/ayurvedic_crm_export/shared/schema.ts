import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Products Table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
});

// Customers Table
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  address: text("address"),
  notes: text("notes"),
  purchasedProducts: integer("purchased_products").array(),
  rating: integer("rating"),
  lastVisit: timestamp("last_visit"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  name: true,
  phone: true,
  email: true,
  address: true,
  notes: true,
  purchasedProducts: true,
  rating: true,
  lastVisit: true,
});

// Follow Ups Table
export const followUps = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  notes: text("notes").notNull(),
  status: text("status").notNull().default("pending"),
  scheduledDate: timestamp("scheduled_date").notNull(),
  completedAt: timestamp("completed_at"),
  feedback: jsonb("feedback"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertFollowUpSchema = createInsertSchema(followUps).pick({
  customerId: true,
  notes: true,
  status: true,
  scheduledDate: true,
  completedAt: true,
  feedback: true,
});

// Feedback Type
export type Feedback = {
  satisfaction: 1 | 2 | 3 | 4 | 5;
  comments?: string;
};

// Export Types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type FollowUp = typeof followUps.$inferSelect;
export type InsertFollowUp = z.infer<typeof insertFollowUpSchema>;
