import { useState, useEffect, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Customer, Product, FollowUp } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

export function useSupabase() {
  const [isConnected, setIsConnected] = useState<boolean>(true); // Always connected
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [followUps, setFollowUps] = useState<FollowUp[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const supabaseRef = useRef<SupabaseClient | null>(null);
  const { toast } = useToast();
  
  // Supabase URL and key
  const supabaseUrl = 'https://ienbuipczkhtfjntbder.supabase.co';
  const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImllbmJ1aXBjemtodGZqbnRiZGVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc0MDI1MzEsImV4cCI6MjA2Mjk3ODUzMX0.rddN3vLsdb6kAx8V-HyvZ5TrXDLJRAC2M0B0Dgv0vA4';

  // Initialize data on mount
  useEffect(() => {
    // Initialize Supabase client and automatically connect
    const setupSupabase = async () => {
      try {
        // Create Supabase client
        supabaseRef.current = createClient(supabaseUrl, supabaseKey);
        
        // Always attempt to connect to Supabase
        console.log('Initializing connection to Supabase...');
        
        try {
          // Try to load data from the API (Supabase)
          const customersResponse = await apiRequest('GET', '/api/customers', undefined);
          const followUpsResponse = await apiRequest('GET', '/api/followups', undefined);
          const productsResponse = await apiRequest('GET', '/api/products', undefined);
          
          const customersData = await customersResponse.json();
          const followUpsData = await followUpsResponse.json();
          const productsData = await productsResponse.json();
          
          setCustomers(customersData);
          setFollowUps(followUpsData);
          setProducts(productsData);
          
          // Set up real-time subscription
          setupRealtimeSubscription();
          
          console.log('Connected to Supabase successfully');
        } catch (error) {
          console.error('Error connecting to Supabase API:', error);
          // Load local data as backup
          await loadLocalData();
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error initializing Supabase:', error);
        await loadLocalData();
        setLoading(false);
      }
    };
    
    setupSupabase();
    
    // Cleanup function to remove subscriptions
    return () => {
      if (supabaseRef.current) {
        supabaseRef.current.removeAllChannels();
      }
    };
  }, []);

  const loadLocalData = async () => {
    try {
      // Load customers
      const storedCustomers = localStorage.getItem('AYURVEDIC_CRM_CUSTOMERS');
      if (storedCustomers) {
        setCustomers(JSON.parse(storedCustomers));
      }

      // Load follow-ups
      const storedFollowUps = localStorage.getItem('AYURVEDIC_CRM_FOLLOWUPS');
      if (storedFollowUps) {
        setFollowUps(JSON.parse(storedFollowUps));
      }

      // Load products
      const storedProducts = localStorage.getItem('AYURVEDIC_CRM_PRODUCTS');
      if (storedProducts) {
        setProducts(JSON.parse(storedProducts));
      } else {
        // Use default products if none exist
        const defaultProducts: Product[] = [
          { id: 1, name: 'Ashwagandha' },
          { id: 2, name: 'Triphala' },
          { id: 3, name: 'Brahmi' },
          { id: 4, name: 'Turmeric' },
          { id: 5, name: 'Shilajit' },
          { id: 6, name: 'Neem' },
          { id: 7, name: 'Amla' },
          { id: 8, name: 'Tulsi' },
          { id: 9, name: 'Guduchi' },
          { id: 10, name: 'Shatavari' }
        ];
        setProducts(defaultProducts);
        localStorage.setItem('AYURVEDIC_CRM_PRODUCTS', JSON.stringify(defaultProducts));
      }
    } catch (error) {
      console.error('Error loading local data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load local data',
        variant: 'destructive'
      });
    }
  };

  const saveLocalData = () => {
    try {
      localStorage.setItem('AYURVEDIC_CRM_CUSTOMERS', JSON.stringify(customers));
      localStorage.setItem('AYURVEDIC_CRM_FOLLOWUPS', JSON.stringify(followUps));
      localStorage.setItem('AYURVEDIC_CRM_PRODUCTS', JSON.stringify(products));
    } catch (error) {
      console.error('Error saving local data:', error);
    }
  };

  // Connect to Supabase
  const connect = async () => {
    try {
      // Try to fetch data from API
      const customersResponse = await apiRequest('GET', '/api/customers', undefined);
      const followUpsResponse = await apiRequest('GET', '/api/followups', undefined);
      const productsResponse = await apiRequest('GET', '/api/products', undefined);
      
      const customersData = await customersResponse.json();
      const followUpsData = await followUpsResponse.json();
      const productsData = await productsResponse.json();
      
      setCustomers(customersData);
      setFollowUps(followUpsData);
      setProducts(productsData);
      setIsConnected(true);
      
      // Remember connection state
      localStorage.setItem('AYURVEDIC_CRM_CONNECTED', 'true');
      
      // Setup realtime subscription
      setupRealtimeSubscription();
      
      return true;
    } catch (error) {
      console.error('Error connecting to Supabase:', error);
      setIsConnected(false);
      localStorage.setItem('AYURVEDIC_CRM_CONNECTED', 'false');
      
      // Fallback to local data
      loadLocalData();
      
      throw error;
    }
  };

  const setupRealtimeSubscription = () => {
    if (!supabaseRef.current) {
      console.warn('Supabase client not initialized. Using polling instead.');
      // Fallback to polling if Supabase client isn't available
      const pollInterval = setInterval(async () => {
        if (isConnected) {
          try {
            const customersResponse = await apiRequest('GET', '/api/customers', undefined);
            const followUpsResponse = await apiRequest('GET', '/api/followups', undefined);
            const productsResponse = await apiRequest('GET', '/api/products', undefined);
            
            const customersData = await customersResponse.json();
            const followUpsData = await followUpsResponse.json();
            const productsData = await productsResponse.json();
            
            setCustomers(customersData);
            setFollowUps(followUpsData);
            setProducts(productsData);
          } catch (error) {
            console.error('Error polling for updates:', error);
          }
        }
      }, 10000); // Poll every 10 seconds
      
      return () => clearInterval(pollInterval);
    }
    
    // Set up real-time subscriptions using Supabase
    try {
      // Subscribe to changes in customers table
      const customersChannel = supabaseRef.current
        .channel('customers-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'customers' 
        }, (payload) => {
          console.log('Received real-time update for customers:', payload);
          // Refresh customers data
          apiRequest('GET', '/api/customers', undefined)
            .then(response => response.json())
            .then(data => setCustomers(data))
            .catch(error => console.error('Error refreshing customers:', error));
        })
        .subscribe();
      
      // Subscribe to changes in follow_ups table
      const followUpsChannel = supabaseRef.current
        .channel('followups-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'follow_ups' 
        }, (payload) => {
          console.log('Received real-time update for follow-ups:', payload);
          // Refresh follow-ups data
          apiRequest('GET', '/api/followups', undefined)
            .then(response => response.json())
            .then(data => setFollowUps(data))
            .catch(error => console.error('Error refreshing follow-ups:', error));
        })
        .subscribe();
      
      // Subscribe to changes in products table
      const productsChannel = supabaseRef.current
        .channel('products-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'products' 
        }, (payload) => {
          console.log('Received real-time update for products:', payload);
          // Refresh products data
          apiRequest('GET', '/api/products', undefined)
            .then(response => response.json())
            .then(data => setProducts(data))
            .catch(error => console.error('Error refreshing products:', error));
        })
        .subscribe();
      
      return () => {
        supabaseRef.current?.removeChannel(customersChannel);
        supabaseRef.current?.removeChannel(followUpsChannel);
        supabaseRef.current?.removeChannel(productsChannel);
      };
    } catch (error) {
      console.error('Error setting up real-time subscriptions:', error);
      // Fallback to polling if real-time subscriptions fail
      const pollInterval = setInterval(async () => {
        if (isConnected) {
          try {
            const customersResponse = await apiRequest('GET', '/api/customers', undefined);
            const followUpsResponse = await apiRequest('GET', '/api/followups', undefined);
            const productsResponse = await apiRequest('GET', '/api/products', undefined);
            
            const customersData = await customersResponse.json();
            const followUpsData = await followUpsResponse.json();
            const productsData = await productsResponse.json();
            
            setCustomers(customersData);
            setFollowUps(followUpsData);
            setProducts(productsData);
          } catch (error) {
            console.error('Error polling for updates:', error);
          }
        }
      }, 10000); // Poll every 10 seconds
      
      return () => clearInterval(pollInterval);
    }
  };

  // Add a new customer
  const addCustomer = async (customer: Customer) => {
    try {
      if (isConnected) {
        const response = await apiRequest('POST', '/api/customers', customer);
        const newCustomer = await response.json();
        setCustomers(prev => [...prev, newCustomer]);
      } else {
        // Save locally
        setCustomers(prev => [...prev, customer]);
        saveLocalData();
      }
    } catch (error) {
      console.error('Error adding customer:', error);
      
      // Fallback to local storage
      setCustomers(prev => [...prev, customer]);
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  // Update a customer
  const updateCustomer = async (customer: Customer) => {
    try {
      if (isConnected) {
        await apiRequest('PUT', `/api/customers/${customer.id}`, customer);
        setCustomers(prev => prev.map(c => c.id === customer.id ? customer : c));
      } else {
        // Update locally
        setCustomers(prev => prev.map(c => c.id === customer.id ? customer : c));
        saveLocalData();
      }
    } catch (error) {
      console.error('Error updating customer:', error);
      
      // Fallback to local storage
      setCustomers(prev => prev.map(c => c.id === customer.id ? customer : c));
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  // Delete a customer
  const deleteCustomer = async (customerId: number) => {
    try {
      if (isConnected) {
        await apiRequest('DELETE', `/api/customers/${customerId}`, undefined);
        setCustomers(prev => prev.filter(c => c.id !== customerId));
        
        // Also delete associated follow-ups
        const relatedFollowUps = followUps.filter(f => f.customerId === customerId);
        for (const followUp of relatedFollowUps) {
          await apiRequest('DELETE', `/api/followups/${followUp.id}`, undefined);
        }
        setFollowUps(prev => prev.filter(f => f.customerId !== customerId));
      } else {
        // Delete locally
        setCustomers(prev => prev.filter(c => c.id !== customerId));
        setFollowUps(prev => prev.filter(f => f.customerId !== customerId));
        saveLocalData();
      }
    } catch (error) {
      console.error('Error deleting customer:', error);
      
      // Fallback to local storage
      setCustomers(prev => prev.filter(c => c.id !== customerId));
      setFollowUps(prev => prev.filter(f => f.customerId !== customerId));
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  // Add a follow-up
  const addFollowUp = async (followUp: FollowUp) => {
    try {
      if (isConnected) {
        const response = await apiRequest('POST', '/api/followups', followUp);
        const newFollowUp = await response.json();
        setFollowUps(prev => [...prev, newFollowUp]);
      } else {
        // Save locally
        setFollowUps(prev => [...prev, followUp]);
        saveLocalData();
      }
    } catch (error) {
      console.error('Error adding follow-up:', error);
      
      // Fallback to local storage
      setFollowUps(prev => [...prev, followUp]);
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  // Update a follow-up
  const updateFollowUp = async (followUp: FollowUp) => {
    try {
      if (isConnected) {
        await apiRequest('PUT', `/api/followups/${followUp.id}`, followUp);
        setFollowUps(prev => prev.map(f => f.id === followUp.id ? followUp : f));
      } else {
        // Update locally
        setFollowUps(prev => prev.map(f => f.id === followUp.id ? followUp : f));
        saveLocalData();
      }
    } catch (error) {
      console.error('Error updating follow-up:', error);
      
      // Fallback to local storage
      setFollowUps(prev => prev.map(f => f.id === followUp.id ? followUp : f));
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  // Delete a follow-up
  const deleteFollowUp = async (followUpId: number) => {
    try {
      if (isConnected) {
        await apiRequest('DELETE', `/api/followups/${followUpId}`, undefined);
        setFollowUps(prev => prev.filter(f => f.id !== followUpId));
      } else {
        // Delete locally
        setFollowUps(prev => prev.filter(f => f.id !== followUpId));
        saveLocalData();
      }
    } catch (error) {
      console.error('Error deleting follow-up:', error);
      
      // Fallback to local storage
      setFollowUps(prev => prev.filter(f => f.id !== followUpId));
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  // Add a product
  const addProduct = async (name: string) => {
    try {
      // Check if product already exists
      if (products.some(p => p.name.toLowerCase() === name.toLowerCase())) {
        throw new Error(`Product "${name}" already exists`);
      }
      
      const newProduct: Product = {
        id: Math.max(0, ...products.map(p => p.id)) + 1,
        name
      };
      
      if (isConnected) {
        const response = await apiRequest('POST', '/api/products', newProduct);
        const savedProduct = await response.json();
        setProducts(prev => [...prev, savedProduct]);
      } else {
        // Save locally
        setProducts(prev => [...prev, newProduct]);
        saveLocalData();
      }
    } catch (error) {
      console.error('Error adding product:', error);
      
      if (!isConnected) {
        // Only add locally if error is from API, not validation
        if (error.message !== `Product "${name}" already exists`) {
          const newProduct: Product = {
            id: Math.max(0, ...products.map(p => p.id)) + 1,
            name
          };
          setProducts(prev => [...prev, newProduct]);
          saveLocalData();
        }
      }
      
      throw error;
    }
  };

  // Remove a product
  const removeProduct = async (productId: number) => {
    try {
      if (isConnected) {
        await apiRequest('DELETE', `/api/products/${productId}`, undefined);
        setProducts(prev => prev.filter(p => p.id !== productId));
      } else {
        // Delete locally
        setProducts(prev => prev.filter(p => p.id !== productId));
        saveLocalData();
      }
    } catch (error) {
      console.error('Error removing product:', error);
      
      // Fallback to local storage
      setProducts(prev => prev.filter(p => p.id !== productId));
      saveLocalData();
      
      if (isConnected) {
        throw error;
      }
    }
  };

  return {
    isConnected,
    connect,
    customers,
    followUps,
    products,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addFollowUp,
    updateFollowUp,
    deleteFollowUp,
    addProduct,
    removeProduct
  };
}
