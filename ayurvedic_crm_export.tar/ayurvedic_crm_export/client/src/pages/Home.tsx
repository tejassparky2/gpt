import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CustomersTab from "@/components/CustomersTab";
import FollowupsTab from "@/components/FollowupsTab";
import AnalyticsTab from "@/components/AnalyticsTab";
import BusinessTipsTab from "@/components/BusinessTipsTab";
import AddEditCustomerModal from "@/components/AddEditCustomerModal";
import DeleteConfirmationModal from "@/components/DeleteConfirmationModal";
import ManageProductsModal from "@/components/ManageProductsModal";
import { useSupabase } from "@/hooks/useSupabase";
import { useToast } from "@/hooks/use-toast";
import { Customer, Product, FollowUp } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState<string>("customers");
  const { toast } = useToast();
  const [search, setSearch] = useState<string>("");
  const [ratingFilter, setRatingFilter] = useState<string>("all");
  
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState<boolean>(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [isProductsModalOpen, setIsProductsModalOpen] = useState<boolean>(false);
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);
  
  const { 
    isConnected, 
    connect, 
    customers, 
    followUps, 
    products,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addProduct,
    removeProduct
  } = useSupabase();

  const handleAddCustomer = () => {
    setSelectedCustomer(null);
    setIsAddEditModalOpen(true);
  };

  const handleEditCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsAddEditModalOpen(true);
  };

  const handleDeleteCustomer = (customer: Customer) => {
    setCustomerToDelete(customer);
    setIsDeleteModalOpen(true);
  };

  const handleSaveCustomer = async (customer: Customer, isNew: boolean) => {
    try {
      if (isNew) {
        await addCustomer(customer);
        toast({
          title: "Customer Added",
          description: "Customer has been added successfully",
          variant: "success"
        });
      } else {
        await updateCustomer(customer);
        toast({
          title: "Customer Updated",
          description: "Customer has been updated successfully",
          variant: "success"
        });
      }
      setIsAddEditModalOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${isNew ? 'add' : 'update'} customer: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const handleConfirmDelete = async () => {
    if (!customerToDelete) return;
    
    try {
      await deleteCustomer(customerToDelete.id);
      toast({
        title: "Customer Deleted",
        description: "Customer has been deleted successfully",
        variant: "success"
      });
      setIsDeleteModalOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to delete customer: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const handleConnectSupabase = async () => {
    try {
      const result = await connect();
      if (result) {
        toast({
          title: "Connected to Supabase",
          description: "Real-time synchronization is now active",
          variant: "success"
        });
      }
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: `Could not connect to Supabase: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar isConnected={isConnected} onConnect={handleConnectSupabase} />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 border-b border-gray-200 w-full justify-start bg-transparent">
            <TabsTrigger 
              value="customers" 
              className="px-4 py-3 text-sm font-medium data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
            >
              CUSTOMERS
            </TabsTrigger>
            <TabsTrigger 
              value="followups" 
              className="px-4 py-3 text-sm font-medium data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
            >
              FOLLOW-UPS
            </TabsTrigger>
            <TabsTrigger 
              value="analytics" 
              className="px-4 py-3 text-sm font-medium data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
            >
              ANALYTICS
            </TabsTrigger>
            <TabsTrigger 
              value="tips" 
              className="px-4 py-3 text-sm font-medium data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
            >
              BUSINESS TIPS
            </TabsTrigger>
          </TabsList>

          <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6 space-y-4 md:space-y-0">
            <div className="md:w-2/3">
              <div className="relative">
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search customers..."
                  className="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-primary"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="text-gray-500 h-4 w-4" />
                </div>
              </div>
            </div>
            <div className="md:w-1/3 md:ml-4">
              <div className="flex items-center p-2 bg-gray-100 rounded-lg">
                <Filter className="text-primary mr-2 h-4 w-4" />
                <span className="text-sm text-gray-700 mr-2">Rating:</span>
                <Select value={ratingFilter} onValueChange={setRatingFilter}>
                  <SelectTrigger className="bg-transparent border-0 text-sm text-gray-700 focus:ring-0 p-0 h-auto">
                    <SelectValue placeholder="All Ratings" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Ratings</SelectItem>
                    <SelectItem value="5">5 Stars</SelectItem>
                    <SelectItem value="4">4 Stars</SelectItem>
                    <SelectItem value="3">3 Stars</SelectItem>
                    <SelectItem value="2">2 Stars</SelectItem>
                    <SelectItem value="1">1 Star</SelectItem>
                    <SelectItem value="0">Unrated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <TabsContent value="customers" className="mt-0">
            <CustomersTab 
              customers={customers} 
              products={products}
              search={search}
              ratingFilter={ratingFilter}
              onAddCustomer={handleAddCustomer} 
              onEditCustomer={handleEditCustomer}
              onDeleteCustomer={handleDeleteCustomer}
              onManageProducts={() => setIsProductsModalOpen(true)}
            />
          </TabsContent>
          
          <TabsContent value="followups" className="mt-0">
            <FollowupsTab followUps={followUps} customers={customers} />
          </TabsContent>
          
          <TabsContent value="analytics" className="mt-0">
            <AnalyticsTab customers={customers} followUps={followUps} />
          </TabsContent>
          
          <TabsContent value="tips" className="mt-0">
            <BusinessTipsTab />
          </TabsContent>
        </Tabs>
      </main>

      <AddEditCustomerModal
        isOpen={isAddEditModalOpen}
        onClose={() => setIsAddEditModalOpen(false)}
        onSave={handleSaveCustomer}
        customer={selectedCustomer}
        products={products}
      />

      <DeleteConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        customer={customerToDelete}
      />

      <ManageProductsModal
        isOpen={isProductsModalOpen}
        onClose={() => setIsProductsModalOpen(false)}
        products={products}
        onAddProduct={addProduct}
        onRemoveProduct={removeProduct}
      />
    </div>
  );
}
