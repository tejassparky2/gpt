import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import { Customer } from "@shared/schema";

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  customer: Customer | null;
}

export default function DeleteConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  customer
}: DeleteConfirmationModalProps) {
  if (!customer) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-white rounded-xl shadow-xl max-w-md w-full">
        <div className="p-6">
          <div className="text-center mb-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 text-red-500 mb-4">
              <AlertTriangle className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Delete Customer</h3>
            <p className="text-gray-600" id="deleteConfirmationText">
              Are you sure you want to delete <span className="font-medium">{customer.name}</span>? This action cannot be undone.
            </p>
          </div>
          
          <DialogFooter className="flex justify-center space-x-3 mt-6">
            <Button 
              id="cancelDeleteBtn"
              variant="outline"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200"
            >
              Cancel
            </Button>
            <Button 
              id="confirmDeleteBtn"
              variant="destructive"
              onClick={onConfirm}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
            >
              Yes, Delete
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
