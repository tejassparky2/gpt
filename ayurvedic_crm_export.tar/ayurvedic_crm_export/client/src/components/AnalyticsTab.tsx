import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Customer, FollowUp } from "@shared/schema";
import { BarChart, BarChart2, PieChart, LineChart, Calendar, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AnalyticsTabProps {
  customers: Customer[];
  followUps: FollowUp[];
}

export default function AnalyticsTab({ customers, followUps }: AnalyticsTabProps) {
  const { toast } = useToast();
  const [startDate, setStartDate] = useState<string>(() => {
    const date = new Date();
    date.setMonth(date.getMonth() - 6);
    return date.toISOString().substr(0, 10);
  });
  
  const [endDate, setEndDate] = useState<string>(() => {
    return new Date().toISOString().substr(0, 10);
  });
  
  useEffect(() => {
    // This will only execute when the component is mounted
    updateAllCharts();
    
    // We need to import Chart.js dynamically since it requires window object
    const initCharts = async () => {
      try {
        await import('chart.js/auto');
        updateAllCharts();
      } catch (error) {
        console.error('Failed to load Chart.js:', error);
      }
    };
    
    initCharts();
  }, []);
  
  const updateAllCharts = () => {
    updateMetrics();
    updateProductSalesChart();
    updateFeedbackPieChart();
    updateCustomerAcquisitionChart();
  };
  
  const updateMetrics = () => {
    // Calculate metrics based on current date range
    const startDateTime = new Date(startDate).getTime();
    const endDateTime = new Date(endDate);
    endDateTime.setHours(23, 59, 59, 999);
    const endTimeValue = endDateTime.getTime();
    
    // Filter customers in date range
    const filteredCustomers = customers.filter(customer => {
      const createdAt = new Date(customer.createdAt).getTime();
      return createdAt >= startDateTime && createdAt <= endTimeValue;
    });
    
    // Filter follow-ups in date range
    const filteredFollowUps = followUps.filter(followUp => {
      const createdAt = new Date(followUp.createdAt).getTime();
      return createdAt >= startDateTime && createdAt <= endTimeValue;
    });
    
    // Calculate metrics
    const totalCustomers = customers.length;
    
    // New customers this month
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    const newCustomersThisMonth = customers.filter(customer => {
      const createdAt = new Date(customer.createdAt);
      return createdAt.getMonth() === currentMonth && createdAt.getFullYear() === currentYear;
    }).length;
    
    // Completed follow-ups
    const completedFollowUps = followUps.filter(followUp => followUp.status === 'completed').length;
    
    // Feedback percentage
    const followUpsWithFeedback = followUps.filter(followUp => 
      followUp.status === 'completed' && followUp.feedback && followUp.feedback.satisfaction
    ).length;
    
    let feedbackPercentage = 0;
    if (completedFollowUps > 0) {
      feedbackPercentage = Math.round((followUpsWithFeedback / completedFollowUps) * 100);
    }
    
    // Update metric elements
    const totalCustomersEl = document.getElementById('totalCustomersMetric');
    const newCustomersEl = document.getElementById('newCustomersMetric');
    const completedFollowupsEl = document.getElementById('completedFollowupsMetric');
    const feedbackPercentEl = document.getElementById('feedbackPercentMetric');
    
    if (totalCustomersEl) totalCustomersEl.textContent = totalCustomers.toString();
    if (newCustomersEl) newCustomersEl.textContent = newCustomersThisMonth.toString();
    if (completedFollowupsEl) completedFollowupsEl.textContent = completedFollowUps.toString();
    if (feedbackPercentEl) feedbackPercentEl.textContent = `${feedbackPercentage}%`;
  };
  
  const updateProductSalesChart = () => {
    // This is just a placeholder implementation
    // In a real application, you would process the actual data and update the chart
    console.log('Product sales chart would be updated here');
  };
  
  const updateFeedbackPieChart = () => {
    // This is just a placeholder implementation
    console.log('Feedback pie chart would be updated here');
  };
  
  const updateCustomerAcquisitionChart = () => {
    // This is just a placeholder implementation
    console.log('Customer acquisition chart would be updated here');
  };
  
  const handleDateRangeUpdate = () => {
    // Validate date range
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (start > end) {
      toast({
        title: "Invalid Date Range",
        description: "Start date cannot be after end date",
        variant: "destructive"
      });
      return;
    }
    
    updateAllCharts();
    
    toast({
      title: "Analytics Updated",
      description: "The analytics data has been updated for the selected date range",
      variant: "success"
    });
  };
  
  const exportCustomersToCSV = () => {
    if (customers.length === 0) {
      toast({
        title: "Export Failed",
        description: "No customers to export",
        variant: "destructive"
      });
      return;
    }
    
    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Add headers
    csvContent += "Name,Phone,Email,Address,Products,Last Visit,Rating,Created\n";
    
    // Add customer data
    customers.forEach(customer => {
      const row = [
        `"${customer.name}"`,
        `"${customer.phone || ''}"`,
        `"${customer.email || ''}"`,
        `"${customer.address || ''}"`,
        `"${customer.purchasedProducts.join(', ')}"`,
        `"${customer.lastVisit || ''}"`,
        `"${customer.rating || 0}"`,
        `"${customer.createdAt}"`
      ];
      
      csvContent += row.join(',') + '\n';
    });
    
    // Create download link
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "ayurvedic_crm_customers.csv");
    document.body.appendChild(link);
    
    // Trigger download
    link.click();
    
    // Clean up
    document.body.removeChild(link);
    
    toast({
      title: "Export Successful",
      description: `${customers.length} customers exported to CSV`,
      variant: "success"
    });
  };
  
  return (
    <div>
      <Card className="bg-white rounded-xl shadow-sm mb-6">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
              <BarChart2 className="text-primary mr-2 h-5 w-5" />
              Business Analytics
            </CardTitle>
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-2">
                <div>
                  <label htmlFor="analyticsStartDate" className="text-xs text-gray-500 block mb-1">Start Date</label>
                  <Input 
                    id="analyticsStartDate"
                    type="date" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="analyticsEndDate" className="text-xs text-gray-500 block mb-1">End Date</label>
                  <Input 
                    id="analyticsEndDate"
                    type="date" 
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div className="flex flex-col justify-end">
                  <Button 
                    id="updateAnalyticsBtn"
                    onClick={handleDateRangeUpdate}
                    className="h-9"
                  >
                    Update
                  </Button>
                </div>
              </div>
              
              <div className="flex flex-col justify-end" id="exportBtnContainer">
                <Button 
                  id="exportCustomersBtn"
                  onClick={exportCustomersToCSV}
                  variant="outline"
                  className="h-9"
                >
                  <Download className="h-4 w-4 mr-1" /> Export
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="p-4 bg-gradient-to-br from-green-50 to-teal-50 rounded-lg border border-green-100">
              <div className="text-sm text-gray-500 mb-1">Total Customers</div>
              <div className="text-2xl font-bold text-gray-800" id="totalCustomersMetric">{customers.length}</div>
            </div>
            
            <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
              <div className="text-sm text-gray-500 mb-1">New This Month</div>
              <div className="text-2xl font-bold text-gray-800" id="newCustomersMetric">
                {
                  customers.filter(customer => {
                    const createdAt = new Date(customer.createdAt);
                    const now = new Date();
                    return createdAt.getMonth() === now.getMonth() && createdAt.getFullYear() === now.getFullYear();
                  }).length
                }
              </div>
            </div>
            
            <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-100">
              <div className="text-sm text-gray-500 mb-1">Completed Follow-ups</div>
              <div className="text-2xl font-bold text-gray-800" id="completedFollowupsMetric">
                {followUps.filter(followUp => followUp.status === 'completed').length}
              </div>
            </div>
            
            <div className="p-4 bg-gradient-to-br from-amber-50 to-yellow-50 rounded-lg border border-amber-100">
              <div className="text-sm text-gray-500 mb-1">Feedback Rate</div>
              <div className="text-2xl font-bold text-gray-800" id="feedbackPercentMetric">
                {(() => {
                  const completedFollowUps = followUps.filter(followUp => followUp.status === 'completed').length;
                  const followUpsWithFeedback = followUps.filter(followUp => 
                    followUp.status === 'completed' && followUp.feedback && followUp.feedback.satisfaction
                  ).length;
                  
                  let feedbackPercentage = 0;
                  if (completedFollowUps > 0) {
                    feedbackPercentage = Math.round((followUpsWithFeedback / completedFollowUps) * 100);
                  }
                  
                  return `${feedbackPercentage}%`;
                })()}
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="text-lg font-medium text-gray-800 mb-4 flex items-center">
                <BarChart className="h-5 w-5 text-primary mr-2" /> Top Products
              </h3>
              <div className="h-64">
                <canvas id="productBarChart"></canvas>
              </div>
            </div>
            
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="text-lg font-medium text-gray-800 mb-4 flex items-center">
                <PieChart className="h-5 w-5 text-primary mr-2" /> Customer Satisfaction
              </h3>
              <div className="h-64">
                <canvas id="satisfactionChart"></canvas>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <h3 className="text-lg font-medium text-gray-800 mb-4 flex items-center">
              <LineChart className="h-5 w-5 text-primary mr-2" /> Customer Acquisition
            </h3>
            <div className="h-64">
              <canvas id="acquisitionChart"></canvas>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
