import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lightbulb, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BusinessTipsTab() {
  const { toast } = useToast();
  const [aiQuery, setAiQuery] = useState<string>("");
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  const handleAiQuery = () => {
    if (!aiQuery.trim()) {
      toast({
        title: "Query Required",
        description: "Please enter a question to get AI assistance",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    setAiResponse(null);
    
    // Simulate AI response (in a real app, this would call an API)
    setTimeout(() => {
      const responses: Record<string, string> = {
        'improve customer retention': 'To improve customer retention in your Ayurvedic beauty business:<ul class="list-disc pl-5 mt-2 space-y-1"><li>Create a personalized follow-up schedule for each client</li><li>Offer loyalty rewards for repeat purchases</li><li>Send seasonal product recommendations based on their dosha type</li><li>Host exclusive workshops for existing customers</li><li>Develop custom product formulations for long-term clients</li></ul>',
        'increase sales': 'To increase sales in your Ayurvedic beauty business:<ul class="list-disc pl-5 mt-2 space-y-1"><li>Bundle complementary products together</li><li>Create seasonal promotions tied to Ayurvedic principles</li><li>Offer consultation packages that include product recommendations</li><li>Develop a referral program with incentives</li><li>Partner with local yoga studios or wellness centers</li></ul>',
        'default': 'Based on Ayurvedic business principles, here are some recommendations:<ul class="list-disc pl-5 mt-2 space-y-1"><li>Tailor products and services to individual doshas (Vata, Pitta, Kapha)</li><li>Educate customers about the science and tradition behind Ayurveda</li><li>Maintain authentic sourcing of ingredients for better results</li><li>Create a calm, balanced atmosphere in your physical space</li><li>Focus on holistic benefits rather than quick fixes</li></ul>'
      };
      
      let response = responses.default;
      const queryLower = aiQuery.toLowerCase();
      
      for (const keyword in responses) {
        if (keyword !== 'default' && queryLower.includes(keyword)) {
          response = responses[keyword];
          break;
        }
      }
      
      setAiResponse(response);
      setIsLoading(false);
    }, 2000);
  };
  
  return (
    <div className="space-y-6">
      <Card className="bg-white rounded-xl shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
            <Lightbulb className="text-primary mr-2 h-5 w-5" />
            AI Assistant
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <label htmlFor="aiQueryInput" className="block text-sm font-medium text-gray-700 mb-2">Ask anything about Ayurvedic beauty business:</label>
            <div className="flex">
              <Input
                id="aiQueryInput"
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                placeholder="E.g., How can I improve customer retention?"
                className="rounded-r-none"
              />
              <Button 
                id="askAiBtn" 
                onClick={handleAiQuery}
                className="bg-primary hover:bg-primary-dark rounded-l-none"
                disabled={isLoading}
              >
                {isLoading ? "Thinking..." : "Get Answer"}
              </Button>
            </div>
          </div>
          
          {(aiResponse || isLoading) && (
            <div id="aiResponseContainer" className="border rounded-lg p-4 bg-gray-50">
              <h3 className="text-md font-medium text-gray-800 mb-2 pb-2 border-b border-gray-200">
                AI Response:
              </h3>
              <div id="aiResponseContent" className="prose text-gray-600">
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary mr-3"></div>
                    Generating response...
                  </div>
                ) : (
                  <div dangerouslySetInnerHTML={{ __html: aiResponse || '' }} />
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300">
          <img 
            src="https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500" 
            alt="Colorful ayurvedic herbs and spices" 
            className="w-full h-48 object-cover"
          />
          <CardContent className="p-4">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Seasonal Product Recommendations</h3>
            <p className="text-gray-600 mb-3">
              Adjust your product offerings based on the changing seasons. Summer requires cooling products like Aloe Vera and Neem, while winter calls for warming ingredients like Ashwagandha.
            </p>
            <Button variant="link" className="text-primary hover:text-primary-dark p-0 h-auto font-medium inline-flex items-center transition-colors duration-200">
              Learn more <ExternalLink className="ml-1 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
        
        <Card className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300">
          <img 
            src="https://images.unsplash.com/photo-1611070931294-c26ee1f6e7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500" 
            alt="Ayurvedic beauty products" 
            className="w-full h-48 object-cover"
          />
          <CardContent className="p-4">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Personalized Dosha Consultations</h3>
            <p className="text-gray-600 mb-3">
              Offer Vata, Pitta, and Kapha dosha assessments to create personalized beauty regimens. This approach increases customer loyalty and perceived value of your services.
            </p>
            <Button variant="link" className="text-primary hover:text-primary-dark p-0 h-auto font-medium inline-flex items-center transition-colors duration-200">
              Learn more <ExternalLink className="ml-1 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
