import { Bell, Leaf, ChevronDown, Menu, X, User, Settings, HelpCircle, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface NavbarProps {
  isConnected: boolean;
}

export default function Navbar({ isConnected }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isMobile = useIsMobile();
  
  return (
    <nav className="bg-gradient-to-r from-primary to-primary-dark shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a href="#" className="text-white text-xl font-bold flex items-center group">
            <Leaf className="mr-2 h-6 w-6 group-hover:rotate-12 transition-transform duration-300" />
            <span className="animated-gradient-text font-semibold">Ayurvedic CRM</span>
            <span 
              id="supabaseStatusIndicator"
              className={`ml-2 w-2.5 h-2.5 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'} transition-colors duration-300 animate-pulse`} 
              title="Supabase Connection Status"
            />
          </a>
          
          {/* Desktop Navigation */}
          {!isMobile && (
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-green-600/80 px-3 py-1 rounded-full text-white text-sm shadow-sm">
                <Database className="h-3.5 w-3.5 mr-1.5" />
                <span>Synced with Supabase</span>
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-white relative">
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="flex flex-col items-start">
                    <span className="font-medium">New follow-up reminder</span>
                    <span className="text-xs text-gray-500">2 minutes ago</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex flex-col items-start">
                    <span className="font-medium">Customer data synced</span>
                    <span className="text-xs text-gray-500">10 minutes ago</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="text-white flex items-center space-x-1">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary-dark text-white text-sm">A</AvatarFallback>
                    </Avatar>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="cursor-pointer">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer">
                    <HelpCircle className="mr-2 h-4 w-4" />
                    <span>Help</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}
          
          {/* Mobile Menu Button */}
          {isMobile && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          )}
        </div>
        
        {/* Mobile Menu */}
        {isMobile && isMenuOpen && (
          <div className="mt-4 py-3 border-t border-primary-light/30 text-white space-y-3">
            <div className="flex items-center space-x-2 px-2 py-2 rounded-md hover:bg-primary-light/20">
              <User className="h-5 w-5" />
              <span>Profile</span>
            </div>
            <div className="flex items-center space-x-2 px-2 py-2 rounded-md hover:bg-primary-light/20">
              <Settings className="h-5 w-5" />
              <span>Settings</span>
            </div>
            <div className="flex items-center space-x-2 px-2 py-2 rounded-md hover:bg-primary-light/20">
              <Bell className="h-5 w-5" />
              <span>Notifications</span>
            </div>
            <div className="flex items-center space-x-2 px-2 py-2 rounded-md hover:bg-primary-light/20">
              <Database className="h-5 w-5" />
              <span>Connected to Supabase</span>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
