import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Customer, Product } from "@shared/schema";
import { Box, Edit, Trash, RotateCcw, Package } from "lucide-react";

interface CustomersTabProps {
  customers: Customer[];
  products: Product[];
  search: string;
  ratingFilter: string;
  onAddCustomer: () => void;
  onEditCustomer: (customer: Customer) => void;
  onDeleteCustomer: (customer: Customer) => void;
  onManageProducts: () => void;
}

export default function CustomersTab({
  customers,
  products,
  search,
  ratingFilter,
  onAddCustomer,
  onEditCustomer,
  onDeleteCustomer,
  onManageProducts
}: CustomersTabProps) {
  // Filter customers based on search and rating filter
  const filteredCustomers = customers.filter(customer => {
    // Search filter
    const searchLower = search.toLowerCase();
    const matchesSearch = 
      !search || 
      customer.name.toLowerCase().includes(searchLower) ||
      (customer.email && customer.email.toLowerCase().includes(searchLower)) ||
      (customer.phone && customer.phone.includes(search)) ||
      (customer.address && customer.address.toLowerCase().includes(searchLower));
    
    // Rating filter
    const ratingValue = parseInt(ratingFilter);
    const matchesRating = 
      ratingFilter === 'all' || 
      (ratingFilter === '0' && !customer.rating) ||
      customer.rating === ratingValue;
    
    return matchesSearch && matchesRating;
  });

  // Helper function to generate initials
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  // Helper function to generate a color based on customer name
  const getAvatarColor = (name: string) => {
    const colors = [
      'bg-primary-light',
      'bg-purple-500',
      'bg-blue-500',
      'bg-amber-500',
      'bg-pink-500',
      'bg-indigo-500',
      'bg-teal-500'
    ];
    
    const hash = name.split('').reduce((acc, char) => {
      return char.charCodeAt(0) + acc;
    }, 0);
    
    return colors[hash % colors.length];
  };

  // Helper function to render star rating
  const renderStarRating = (rating?: number) => {
    if (!rating) {
      return (
        <div className="flex text-gray-300">
          <i className="bi bi-star text-sm"></i>
          <i className="bi bi-star text-sm"></i>
          <i className="bi bi-star text-sm"></i>
          <i className="bi bi-star text-sm"></i>
          <i className="bi bi-star text-sm"></i>
        </div>
      );
    }
    
    return (
      <div className="flex text-yellow-400">
        {[1, 2, 3, 4, 5].map(star => (
          <i 
            key={star} 
            className={`bi ${star <= rating ? 'bi-star-fill' : 'bi-star'} text-sm`}
          ></i>
        ))}
      </div>
    );
  };

  // Helper function to format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Customer Management</h2>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={onManageProducts}
            className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-200 flex items-center"
          >
            <Package className="mr-1 h-4 w-4" /> Products
          </Button>
          <Button
            onClick={onAddCustomer}
            className="px-3 py-2 bg-gradient-to-r from-primary to-primary-dark text-white rounded-lg text-sm hover:shadow-md transition-all duration-200 flex items-center"
          >
            <i className="bi bi-plus-lg mr-1"></i> Add Customer
          </Button>
        </div>
      </div>

      <Card className="bg-white rounded-xl shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md">
        <CardContent className="p-0">
          {filteredCustomers.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Products</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Visit</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredCustomers.map(customer => (
                    <tr key={customer.id} className="hover:bg-gray-50 transition-colors duration-150">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <div className={`h-10 w-10 rounded-full ${getAvatarColor(customer.name)} text-white flex items-center justify-center`}>
                              <span className="text-sm font-medium">{getInitials(customer.name)}</span>
                            </div>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                            <div className="text-sm text-gray-500">{customer.address}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{customer.phone}</div>
                        <div className="text-sm text-gray-500">{customer.email}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-wrap gap-1">
                          {customer.purchasedProducts.map((productId, index) => {
                            const product = products.find(p => p.id === productId);
                            return product ? (
                              <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                {product.name}
                              </span>
                            ) : null;
                          })}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {customer.lastVisit ? formatDate(customer.lastVisit) : 'No visits yet'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {renderStarRating(customer.rating)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark transition-colors duration-200">
                            <RotateCcw className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => onEditCustomer(customer)} 
                            className="text-blue-500 hover:text-blue-700 transition-colors duration-200"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost"
                            size="sm"
                            onClick={() => onDeleteCustomer(customer)} 
                            className="text-red-500 hover:text-red-700 transition-colors duration-200"
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div id="emptyCustomersState" className="py-12 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
                <i className="bi bi-person-plus text-3xl text-primary"></i>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No customers yet</h3>
              <p className="text-gray-500 max-w-md mx-auto mb-4">Start building your customer base by adding your first customer.</p>
              <Button 
                onClick={onAddCustomer}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors duration-200"
              >
                <i className="bi bi-plus-lg mr-1"></i> Add Your First Customer
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
