import { useState, useEffect, ReactNode } from 'react';
import { AlertCircle, CheckCircle, XCircle, Info, X } from 'lucide-react';

interface NotificationProps {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string | ReactNode;
  autoClose?: boolean;
  duration?: number;
  onClose?: () => void;
}

export default function Notification({
  id,
  type,
  message,
  autoClose = true,
  duration = 5000,
  onClose
}: NotificationProps) {
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    if (autoClose) {
      const timer = setTimeout(() => {
        setIsFading(true);
        
        const fadeTimer = setTimeout(() => {
          onClose?.();
        }, 300);
        
        return () => clearTimeout(fadeTimer);
      }, duration);
      
      return () => clearTimeout(timer);
    }
  }, [autoClose, duration, onClose]);

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'info':
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getStyles = () => {
    const baseStyles = "flex items-center p-4 rounded-lg border fade-in notification";
    
    switch (type) {
      case 'success':
        return `${baseStyles} bg-green-100 text-green-800 border-green-200`;
      case 'error':
        return `${baseStyles} bg-red-100 text-red-800 border-red-200`;
      case 'warning':
        return `${baseStyles} bg-yellow-100 text-yellow-800 border-yellow-200`;
      case 'info':
      default:
        return `${baseStyles} bg-blue-100 text-blue-800 border-blue-200`;
    }
  };

  return (
    <div 
      id={id}
      className={`${getStyles()} ${isFading ? 'opacity-0 transform -translate-y-2' : 'opacity-100'}`}
      style={{ transition: 'opacity 0.3s, transform 0.3s' }}
    >
      <div className="mr-3">
        {getIcon()}
      </div>
      <div className="flex-1">{message}</div>
      <button 
        onClick={() => {
          setIsFading(true);
          setTimeout(() => onClose?.(), 300);
        }}
        className="text-gray-500 hover:text-gray-700"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
