import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FollowUp, Customer } from "@shared/schema";
import { Clock, Calendar, CheckCircle, RotateCw } from "lucide-react";

interface FollowupsTabProps {
  followUps: FollowUp[];
  customers: Customer[];
}

export default function FollowupsTab({ followUps, customers }: FollowupsTabProps) {
  const [filter, setFilter] = useState<'today' | 'upcoming' | 'completed' | 'all'>('today');

  // Filter follow-ups based on selected filter
  const filteredFollowUps = followUps.filter(followUp => {
    const followUpDate = new Date(followUp.scheduledDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const isToday = followUpDate.toDateString() === today.toDateString();
    const isUpcoming = followUpDate > today && !isToday;
    const isCompleted = followUp.status === 'completed';
    
    switch (filter) {
      case 'today':
        return isToday && !isCompleted;
      case 'upcoming':
        return isUpcoming && !isCompleted;
      case 'completed':
        return isCompleted;
      case 'all':
      default:
        return true;
    }
  });

  // Find customer by ID
  const getCustomer = (customerId: number) => {
    return customers.find(customer => customer.id === customerId);
  };

  // Helper function to format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return new Intl.DateTimeFormat('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }).format(date);
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
          <RotateCw className="text-primary mr-2 h-5 w-5" />
          Follow-up Management
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex space-x-2 mb-4">
          <Button 
            variant={filter === 'today' ? 'default' : 'outline'} 
            onClick={() => setFilter('today')}
            className={filter === 'today' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700 border border-gray-200'}
          >
            Today
          </Button>
          <Button 
            variant={filter === 'upcoming' ? 'default' : 'outline'} 
            onClick={() => setFilter('upcoming')}
            className={filter === 'upcoming' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700 border border-gray-200'}
          >
            Upcoming
          </Button>
          <Button 
            variant={filter === 'completed' ? 'default' : 'outline'} 
            onClick={() => setFilter('completed')}
            className={filter === 'completed' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700 border border-gray-200'}
          >
            Completed
          </Button>
          <Button 
            variant={filter === 'all' ? 'default' : 'outline'} 
            onClick={() => setFilter('all')}
            className={filter === 'all' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-700 border border-gray-200'}
          >
            All
          </Button>
        </div>
        
        {filteredFollowUps.length > 0 ? (
          <div className="space-y-4">
            {filteredFollowUps.map(followUp => {
              const customer = getCustomer(followUp.customerId);
              if (!customer) return null;
              
              const isToday = new Date(followUp.scheduledDate).toDateString() === new Date().toDateString();
              
              return (
                <div key={followUp.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow duration-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">{customer.name}</h3>
                      <p className="text-sm text-gray-500">Phone: {customer.phone}</p>
                    </div>
                    <div className="flex items-center mt-2 md:mt-0">
                      <Badge className={`mr-2 px-3 py-1 rounded-full text-xs ${
                        followUp.status === 'completed' 
                          ? 'bg-green-100 text-green-800' 
                          : isToday 
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-blue-100 text-blue-800'
                      }`}>
                        {followUp.status === 'completed' ? (
                          <><CheckCircle className="h-3 w-3 mr-1" /> Completed</>
                        ) : isToday ? (
                          <><Clock className="h-3 w-3 mr-1" /> Today</>
                        ) : (
                          <><Calendar className="h-3 w-3 mr-1" /> {formatDate(followUp.scheduledDate)}</>
                        )}
                      </Badge>
                      {followUp.status !== 'completed' && (
                        <Button size="sm" className="bg-primary text-white hover:bg-primary-dark">
                          Complete
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="mt-3">
                    <p className="text-sm text-gray-600">{followUp.notes}</p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
              <Calendar className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No follow-ups found</h3>
            <p className="text-gray-500 max-w-md mx-auto">
              {filter === 'today' ? "You don't have any follow-ups scheduled for today." :
               filter === 'upcoming' ? "You don't have any upcoming follow-ups scheduled." :
               filter === 'completed' ? "You haven't completed any follow-ups yet." :
               "You don't have any follow-ups. Create one from the customer list."}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
