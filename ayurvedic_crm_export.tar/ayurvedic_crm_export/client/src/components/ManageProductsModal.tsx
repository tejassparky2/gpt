import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Trash, Plus } from "lucide-react";

interface ManageProductsModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddProduct: (name: string) => Promise<void>;
  onRemoveProduct: (id: number) => Promise<void>;
}

export default function ManageProductsModal({
  isOpen,
  onClose,
  products,
  onAddProduct,
  onRemoveProduct
}: ManageProductsModalProps) {
  const [newProductName, setNewProductName] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const { toast } = useToast();

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newProductName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a product name",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      await onAddProduct(newProductName.trim());
      setNewProductName("");
      toast({
        title: "Product Added",
        description: `Product "${newProductName.trim()}" added successfully`,
        variant: "success"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to add product: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRemoveProduct = async (product: Product) => {
    if (confirm(`Are you sure you want to remove "${product.name}"? This will not affect existing customers.`)) {
      try {
        await onRemoveProduct(product.id);
        toast({
          title: "Product Removed",
          description: `Product "${product.name}" removed successfully`,
          variant: "success"
        });
      } catch (error) {
        toast({
          title: "Error",
          description: `Failed to remove product: ${error.message}`,
          variant: "destructive"
        });
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-white rounded-xl shadow-xl max-w-2xl w-full">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-gray-800">Manage Products</DialogTitle>
        </DialogHeader>
        
        <div className="p-6">
          <form onSubmit={handleAddProduct} className="mb-4">
            <label htmlFor="newProductName" className="block text-sm font-medium text-gray-700 mb-1">Add New Product</label>
            <div className="flex">
              <Input
                id="newProductName"
                value={newProductName}
                onChange={(e) => setNewProductName(e.target.value)}
                placeholder="Product name"
                className="flex-1 rounded-r-none"
                disabled={isSubmitting}
              />
              <Button 
                type="submit"
                disabled={isSubmitting}
                className="bg-primary hover:bg-primary-dark text-white rounded-l-none"
              >
                <Plus className="h-4 w-4 mr-1" /> Add
              </Button>
            </div>
          </form>
          
          <div className="border rounded-lg overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product Name</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200" id="productTableBody">
                {products.length > 0 ? (
                  products.map(product => (
                    <tr key={product.id} className="hover:bg-gray-50 transition-colors duration-150">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button 
                          variant="ghost"
                          onClick={() => handleRemoveProduct(product)}
                          className="text-red-500 hover:text-red-700 transition-colors duration-200"
                        >
                          <Trash className="h-4 w-4 mr-1" /> Remove
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={2} className="px-6 py-4 text-center text-sm text-gray-500">
                      No products available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
