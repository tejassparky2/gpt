import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Customer, Product } from "@shared/schema";
import { Save, X } from "lucide-react";

interface AddEditCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Customer, isNew: boolean) => void;
  customer: Customer | null;
  products: Product[];
}

export default function AddEditCustomerModal({ 
  isOpen, 
  onClose, 
  onSave, 
  customer, 
  products 
}: AddEditCustomerModalProps) {
  const [name, setName] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [address, setAddress] = useState<string>("");
  const [selectedProducts, setSelectedProducts] = useState<number[]>([]);
  const [notes, setNotes] = useState<string>("");
  
  // Reset form when customer changes
  useEffect(() => {
    if (customer) {
      setName(customer.name);
      setPhone(customer.phone || "");
      setEmail(customer.email || "");
      setAddress(customer.address || "");
      setSelectedProducts(customer.purchasedProducts || []);
      setNotes(customer.notes || "");
    } else {
      // Reset form for new customer
      setName("");
      setPhone("");
      setEmail("");
      setAddress("");
      setSelectedProducts([]);
      setNotes("");
    }
  }, [customer, isOpen]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!name || !phone) {
      return;
    }
    
    const updatedCustomer: Customer = {
      id: customer?.id || Date.now(),
      name,
      phone,
      email: email || undefined,
      address: address || undefined,
      purchasedProducts: selectedProducts,
      notes: notes || undefined,
      createdAt: customer?.createdAt || new Date().toISOString(),
      lastVisit: customer?.lastVisit || undefined,
      rating: customer?.rating || undefined,
    };
    
    onSave(updatedCustomer, !customer);
  };
  
  const handleProductToggle = (productId: number) => {
    setSelectedProducts(prev => {
      if (prev.includes(productId)) {
        return prev.filter(id => id !== productId);
      } else {
        return [...prev, productId];
      }
    });
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-gray-800">{customer ? "Edit Customer" : "Add New Customer"}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium text-gray-700">Name*</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-sm font-medium text-gray-700">Phone*</Label>
              <Input 
                id="phone" 
                value={phone} 
                onChange={(e) => setPhone(e.target.value)} 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary"
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
              <Input 
                id="email" 
                type="email"
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address" className="text-sm font-medium text-gray-700">Address</Label>
              <Input 
                id="address" 
                value={address} 
                onChange={(e) => setAddress(e.target.value)} 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary"
              />
            </div>
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-2">Purchased Products</Label>
            <div id="productSelection" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {products.length > 0 ? (
                products.map((product) => (
                  <div 
                    key={product.id}
                    className="bg-gray-50 p-2 rounded-lg border border-gray-200 transition-colors hover:bg-green-50 hover:border-green-200 cursor-pointer"
                    onClick={() => handleProductToggle(product.id)}
                  >
                    <div className="flex items-center">
                      <Checkbox 
                        id={`product-${product.id}`}
                        checked={selectedProducts.includes(product.id)}
                        onCheckedChange={() => handleProductToggle(product.id)}
                        className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                      />
                      <Label 
                        htmlFor={`product-${product.id}`}
                        className="ml-2 block text-sm text-gray-700 cursor-pointer"
                      >
                        {product.name}
                      </Label>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-full">
                  <div className="alert alert-info">
                    <i className="bi bi-info-circle me-2"></i>No products available. Please add products first.
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="mb-4">
            <Label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-2">Notes</Label>
            <Textarea 
              id="notes" 
              value={notes} 
              onChange={(e) => setNotes(e.target.value)} 
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary"
            />
          </div>
          
          <DialogFooter className="flex justify-end mt-6 space-x-3">
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors duration-200"
            >
              <Save className="mr-1 h-4 w-4" /> Save Customer
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
