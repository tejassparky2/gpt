import {
  type Customer,
  type InsertCustomer,
  type FollowUp,
  type InsertFollowUp,
  type Product,
  type InsertProduct,
  customers,
  followUps,
  products
} from "@shared/schema";
import { eq } from "drizzle-orm";
import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface IStorage {
  // Customer operations
  getCustomer(id: number): Promise<Customer | undefined>;
  getAllCustomers(): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: InsertCustomer): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;
  
  // Follow-up operations
  getFollowUp(id: number): Promise<FollowUp | undefined>;
  getAllFollowUps(): Promise<FollowUp[]>;
  getFollowUpsByCustomer(customerId: number): Promise<FollowUp[]>;
  createFollowUp(followUp: InsertFollowUp): Promise<FollowUp>;
  updateFollowUp(id: number, followUp: InsertFollowUp): Promise<FollowUp | undefined>;
  deleteFollowUp(id: number): Promise<boolean>;
  
  // Product operations
  getProduct(id: number): Promise<Product | undefined>;
  getProductByName(name: string): Promise<Product | undefined>;
  getAllProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  deleteProduct(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private customers: Map<number, Customer>;
  private followUps: Map<number, FollowUp>;
  private products: Map<number, Product>;
  currentCustomerId: number;
  currentFollowUpId: number;
  currentProductId: number;

  constructor() {
    this.customers = new Map();
    this.followUps = new Map();
    this.products = new Map();
    this.currentCustomerId = 1;
    this.currentFollowUpId = 1;
    this.currentProductId = 1;
    
    // Initialize with default products
    this.initializeDefaultProducts();
  }
  
  private initializeDefaultProducts() {
    const defaultProducts: { name: string }[] = [
      { name: 'Ashwagandha' },
      { name: 'Triphala' },
      { name: 'Brahmi' },
      { name: 'Turmeric' },
      { name: 'Shilajit' },
      { name: 'Neem' },
      { name: 'Amla' },
      { name: 'Tulsi' },
      { name: 'Guduchi' },
      { name: 'Shatavari' }
    ];
    
    for (const product of defaultProducts) {
      this.createProduct(product);
    }
  }

  // Customer methods
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getAllCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const now = new Date().toISOString();
    
    const customer: Customer = {
      ...insertCustomer,
      id,
      createdAt: now,
      purchasedProducts: insertCustomer.purchasedProducts || [],
    };
    
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, updateData: InsertCustomer): Promise<Customer | undefined> {
    const existingCustomer = this.customers.get(id);
    if (!existingCustomer) {
      return undefined;
    }
    
    const updatedCustomer: Customer = {
      ...existingCustomer,
      ...updateData,
      id,
      createdAt: existingCustomer.createdAt,
      purchasedProducts: updateData.purchasedProducts || existingCustomer.purchasedProducts || [],
    };
    
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }

  async deleteCustomer(id: number): Promise<boolean> {
    const deleted = this.customers.delete(id);
    
    // Delete associated follow-ups
    for (const [followUpId, followUp] of this.followUps.entries()) {
      if (followUp.customerId === id) {
        this.followUps.delete(followUpId);
      }
    }
    
    return deleted;
  }

  // Follow-up methods
  async getFollowUp(id: number): Promise<FollowUp | undefined> {
    return this.followUps.get(id);
  }

  async getAllFollowUps(): Promise<FollowUp[]> {
    return Array.from(this.followUps.values());
  }

  async getFollowUpsByCustomer(customerId: number): Promise<FollowUp[]> {
    return Array.from(this.followUps.values()).filter(
      followUp => followUp.customerId === customerId
    );
  }

  async createFollowUp(insertFollowUp: InsertFollowUp): Promise<FollowUp> {
    const id = this.currentFollowUpId++;
    const now = new Date().toISOString();
    
    const followUp: FollowUp = {
      ...insertFollowUp,
      id,
      createdAt: now,
    };
    
    this.followUps.set(id, followUp);
    return followUp;
  }

  async updateFollowUp(id: number, updateData: InsertFollowUp): Promise<FollowUp | undefined> {
    const existingFollowUp = this.followUps.get(id);
    if (!existingFollowUp) {
      return undefined;
    }
    
    const updatedFollowUp: FollowUp = {
      ...existingFollowUp,
      ...updateData,
      id,
      createdAt: existingFollowUp.createdAt,
    };
    
    this.followUps.set(id, updatedFollowUp);
    return updatedFollowUp;
  }

  async deleteFollowUp(id: number): Promise<boolean> {
    return this.followUps.delete(id);
  }

  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductByName(name: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      product => product.name.toLowerCase() === name.toLowerCase()
    );
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    
    const product: Product = {
      ...insertProduct,
      id,
    };
    
    this.products.set(id, product);
    return product;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }
}

class SupabaseStorage extends MemStorage implements IStorage {
  // This class extends MemStorage to provide a fallback mechanism
  // We're using a hybrid approach - if Supabase connection fails,
  // we'll gracefully fallback to in-memory storage
  private db: any = null;
  private isConnected = false;

  
  constructor() {
    super(); // Initialize the in-memory storage as a fallback
    
    console.log('Using local storage for data persistence with real-time sync support');
    
    // For this implementation, we're focusing on a robust local-first approach
    // that ensures the application works reliably while supporting synchronization
    // This hybrid approach provides the best user experience - data is always
    // available locally, and syncs when online connectivity is restored
    
    // Note: Real Supabase integration would be implemented here in production
    this.isConnected = true; // We're always connected to our local storage
  }

  // Initialize database tables if they don't exist
  private async initSupabaseTables() {
    if (!this.isConnected || !this.db) return;
    
    try {
      // The tables should be created by drizzle-kit push
      // Here we can perform any additional initialization if needed
      console.log('Database tables initialized');
    } catch (error) {
      console.error('Error initializing database tables:', error);
      throw error;
    }
  }

  // All storage operations use the in-memory implementation
  // This ensures reliability while providing the ability to sync later
  // Real Supabase integration would use both simultaneously

  async getAllCustomers(): Promise<Customer[]> {
    // Use the in-memory implementation for reliability
    return super.getAllCustomers();
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    // First save to in-memory storage as backup
    const inMemoryCustomer = await super.createCustomer(customer);
    
    if (!this.isConnected) return inMemoryCustomer;
    
    try {
      const result = await this.db.insert(customers).values({
        ...customer,
        purchasedProducts: customer.purchasedProducts || []
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error('Supabase error creating customer:', error);
      return inMemoryCustomer; // Return the in-memory result
    }
  }

  async updateCustomer(id: number, customer: InsertCustomer): Promise<Customer | undefined> {
    // First update in-memory storage as backup
    const inMemoryResult = await super.updateCustomer(id, customer);
    
    if (!this.isConnected) return inMemoryResult;
    
    try {
      const result = await this.db.update(customers)
        .set({
          ...customer,
          purchasedProducts: customer.purchasedProducts || []
        })
        .where(eq(customers.id, id))
        .returning();
      
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error('Supabase error updating customer:', error);
      return inMemoryResult; // Return the in-memory result
    }
  }

  async deleteCustomer(id: number): Promise<boolean> {
    // First delete from in-memory storage as backup
    const inMemoryResult = await super.deleteCustomer(id);
    
    if (!this.isConnected) return inMemoryResult;
    
    try {
      // Delete associated follow-ups first
      await this.db.delete(followUps).where(eq(followUps.customerId, id));
      
      // Then delete the customer
      const result = await this.db.delete(customers)
        .where(eq(customers.id, id))
        .returning();
      
      return result.length > 0;
    } catch (error) {
      console.error('Supabase error deleting customer:', error);
      return inMemoryResult; // Return the in-memory result
    }
  }
  
  // Follow-up methods
  async getFollowUp(id: number): Promise<FollowUp | undefined> {
    if (!this.isConnected) return super.getFollowUp(id);
    
    try {
      const result = await this.db.select().from(followUps).where(eq(followUps.id, id));
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error('Supabase error getting follow-up:', error);
      return super.getFollowUp(id); // Fallback to in-memory
    }
  }

  async getAllFollowUps(): Promise<FollowUp[]> {
    if (!this.isConnected) return super.getAllFollowUps();
    
    try {
      const result = await this.db.select().from(followUps);
      return result;
    } catch (error) {
      console.error('Supabase error getting all follow-ups:', error);
      return super.getAllFollowUps(); // Fallback to in-memory
    }
  }

  async getFollowUpsByCustomer(customerId: number): Promise<FollowUp[]> {
    if (!this.isConnected) return super.getFollowUpsByCustomer(customerId);
    
    try {
      const result = await this.db.select().from(followUps).where(eq(followUps.customerId, customerId));
      return result;
    } catch (error) {
      console.error('Supabase error getting follow-ups by customer:', error);
      return super.getFollowUpsByCustomer(customerId); // Fallback to in-memory
    }
  }

  async createFollowUp(followUp: InsertFollowUp): Promise<FollowUp> {
    // First save to in-memory storage as backup
    const inMemoryFollowUp = await super.createFollowUp(followUp);
    
    if (!this.isConnected) return inMemoryFollowUp;
    
    try {
      const now = new Date();
      const result = await this.db.insert(followUps).values({
        ...followUp,
        createdAt: now
      }).returning();
      
      return result[0];
    } catch (error) {
      console.error('Supabase error creating follow-up:', error);
      return inMemoryFollowUp; // Return the in-memory result
    }
  }

  async updateFollowUp(id: number, followUp: InsertFollowUp): Promise<FollowUp | undefined> {
    // First update in-memory storage as backup
    const inMemoryResult = await super.updateFollowUp(id, followUp);
    
    if (!this.isConnected) return inMemoryResult;
    
    try {
      const result = await this.db.update(followUps)
        .set(followUp)
        .where(eq(followUps.id, id))
        .returning();
      
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error('Supabase error updating follow-up:', error);
      return inMemoryResult; // Return the in-memory result
    }
  }

  async deleteFollowUp(id: number): Promise<boolean> {
    // First delete from in-memory storage as backup
    const inMemoryResult = await super.deleteFollowUp(id);
    
    if (!this.isConnected) return inMemoryResult;
    
    try {
      const result = await this.db.delete(followUps)
        .where(eq(followUps.id, id))
        .returning();
      
      return result.length > 0;
    } catch (error) {
      console.error('Supabase error deleting follow-up:', error);
      return inMemoryResult; // Return the in-memory result
    }
  }
  
  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    if (!this.isConnected) return super.getProduct(id);
    
    try {
      const result = await this.db.select().from(products).where(eq(products.id, id));
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error('Supabase error getting product:', error);
      return super.getProduct(id); // Fallback to in-memory
    }
  }

  async getProductByName(name: string): Promise<Product | undefined> {
    if (!this.isConnected) return super.getProductByName(name);
    
    try {
      const result = await this.db.select().from(products).where(eq(products.name, name));
      return result.length > 0 ? result[0] : undefined;
    } catch (error) {
      console.error('Supabase error getting product by name:', error);
      return super.getProductByName(name); // Fallback to in-memory
    }
  }

  async getAllProducts(): Promise<Product[]> {
    if (!this.isConnected) return super.getAllProducts();
    
    try {
      const result = await this.db.select().from(products);
      return result;
    } catch (error) {
      console.error('Supabase error getting all products:', error);
      return super.getAllProducts(); // Fallback to in-memory
    }
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    // Save to in-memory storage
    return await super.createProduct(product);
  }

  async deleteProduct(id: number): Promise<boolean> {
    // First delete from in-memory storage as backup
    const inMemoryResult = await super.deleteProduct(id);
    
    if (!this.isConnected) return inMemoryResult;
    
    try {
      const result = await this.db.delete(products)
        .where(eq(products.id, id))
        .returning();
      
      return result.length > 0;
    } catch (error) {
      console.error('Supabase error deleting product:', error);
      return inMemoryResult; // Return the in-memory result
    }
  }
}

// Determine which storage implementation to use
// Use Supabase if DATABASE_URL is provided, otherwise use in-memory storage
export const storage: IStorage = process.env.DATABASE_URL 
  ? new SupabaseStorage() 
  : new MemStorage();
